# Oracle 院端检查数据 CSV 导出工具

适用于按结算时间批量导出住院、门诊等检查数据。每个配置对象单独生成 CSV 和可供重新导入的建表 SQL，并生成包含行数及 SHA-256 的导出清单。

## 一、环境准备

要求 Python 3.9+，默认使用 python-oracledb Thin 模式，无需安装 Oracle 客户端。

```powershell
cd oracle_csv_export
python -m pip install -r requirements.txt
Copy-Item config.example.json config.json
```

## 二、设置数据库连接

PowerShell 当前窗口：

```powershell
$env:ORACLE_USER = "只读账号"
$env:ORACLE_PASSWORD = "数据库密码"
$env:ORACLE_DSN = "192.168.1.10:1521/HISDB"
```

连接信息不写入配置文件，避免密码随脚本流转。

## 三、修改导出配置

编辑 `config.json`：

- `start_date`：起始日期，包含当天；
- `end_date`：结束日期，不包含当天。例如导出 2026 年 1 月，填写 `2026-01-01` 和 `2026-02-01`；
- `hospital_name`：用于输出文件名；
- `max_workers`：同时导出的表数量，默认 `4`；
- `progress_rows`：每导出多少行输出一次实时进度，默认 `100000`；
- `tables`：逐项配置来源视图、结算日期字段，以及可选的导入目标表名 `target_table_name`；
- `extra_where`：可选附加条件，例如 `CANCEL_FLAG = '0'`，不能包含注释或分号。

脚本执行 `SELECT *`，并通过 Oracle 查询元数据按视图字段顺序自动生成英文表头，不需要在配置中重复维护 `columns`。因此，视图字段名必须符合《医疗机构端数据采集表清单》的英文名称，且不能重名。建议将全部采集口径封装在视图中，以便复核和留痕。

生成的 `.sql` 是与 CSV 字段对应的独立空表建表语句，不再是来源视图定义。字段类型、字符长度和数值精度来自 `ALL_TAB_COLUMNS`。目标表名默认与来源视图名相同，也可通过 `target_table_name` 指定。

`date_column` 有值时按 `start_date <= date_column < end_date` 提取；配置为 `""`、`null` 或直接省略时不添加日期条件，执行全量提取。无论是否全量提取，文件名始终使用配置中的 `start_date`、`end_date` 日期范围，命名规则保持一致。`extra_where` 即使在全量模式下仍然生效。

## 四、执行

```powershell
python .\export_oracle_csv.py --config .\config.json
```

控制台会实时显示每张表的开始时间、提取模式、字段数量、行数进度、耗时及完成状态，并在输出目录生成 `医院名称_导出日志_日期范围.log`。每个并发线程单独建立 Oracle 连接，不在线程之间共享连接。生产环境建议先使用 `max_workers: 4`，再根据数据库负载调整。

单条记录发生日期、LOB、字符编码等转换异常时，脚本会记录来源行号和异常原因，跳过该行后继续导出；日志不会写入该行的患者原始字段。磁盘写入失败、数据库连接中断等系统性错误会终止当前表，但不会影响其他并发表继续执行。导出清单中的 `row_count`、`skipped_row_count`、`source_row_count` 分别表示成功数、跳过数和总处理数。

导出过程中使用 `.part` 临时文件；CSV 和建表 SQL 均成功后才改为正式文件名。任务结束时会生成 `医院名称_完成文件清单_日期范围.txt`，列出最终完成的 CSV、SQL、成功行数、跳过行数和失败表。JSON 清单中的状态为 `completed` 或 `completed_with_skips`，失败产生的 `.part` 文件不会进入完成清单。

命名示例：

```text
聊城市人民医院_住院结算主单_20260101-20260201.csv
聊城市人民医院_住院结算主单_20260101-20260201.sql
聊城市人民医院_导出清单_20260101-20260201.json
```

## 五、输出规则

- 文件编码：UTF-8（无 BOM）；
- 分隔符固定使用标准英文逗号 `,`；
- 字段内容中的英文逗号会直接删除，避免导入时数据串列；
- 空值：空字符串；
- 日期：`YYYY-MM-DD` 或 `YYYY-MM-DD HH24:MI:SS`；
- 数值：普通十进制文本，不使用科学计数法；
- 首行为英文列名；
- 字段含分隔符、双引号或换行时使用双引号包裹，内部双引号写成两个双引号；
- 默认根据 `date_column >= start_date AND date_column < end_date` 提取。

导出清单 JSON 会记录 `"delimiter": ","` 和 `"comma_in_field": "removed"`。请注意：删除字段中的逗号会改变原始文本，例如 `山东省,聊城市` 将导出为 `山东省聊城市`。

## 六、导出后必须核验

1. CSV 数据行数与源查询 `COUNT(*)` 一致；
2. 文件可重新导入测试库，导入后行数一致；
3. 主单 `TOTAL_AMOUNT` 与明细 `COST` 汇总误差不超过 0.5%；
4. 主单与明细 `HISID` 无法关联比例不超过 0.1%；
5. 主单 `HISID` 重复比例不超过 0.1%；
6. 结算日期均在配置区间内，检查周期内每月均有数据；
7. 必填字段非空，负金额能够对应退费业务；
8. 医疗总费用与财务报表一致，医保病例金额与医保端数据一致。
