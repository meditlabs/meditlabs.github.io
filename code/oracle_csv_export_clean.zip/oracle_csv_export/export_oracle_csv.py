#!/usr/bin/env python3
"""按配置将 Oracle 数据流式导出为检查组要求的分隔文本。"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

import oracledb


SAFE_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]*$")
LOG = logging.getLogger("oracle_csv_export")


def configure_logging() -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] [%(threadName)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    LOG.handlers.clear()
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)
    LOG.propagate = False


def add_file_logging(log_path: Path) -> None:
    """将控制台实时日志同步保存到 UTF-8 日志文件。"""
    handler = logging.FileHandler(log_path, encoding="utf-8")
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] [%(threadName)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    LOG.addHandler(handler)


def identifier(value: str) -> str:
    if not SAFE_IDENTIFIER.fullmatch(value):
        raise ValueError(f"不安全的 Oracle 标识符: {value!r}")
    return value.upper()


def safe_filename(value: str) -> str:
    return re.sub(r'[\\/:*?"<>|\r\n]+', "_", value).strip(" .")


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    if not config.get("tables"):
        raise ValueError("配置中 tables 不能为空")
    return config


def env_required(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"环境变量 {name} 未设置")
    return value


def connect(config: dict[str, Any]) -> oracledb.Connection:
    item = config["connection"]
    return oracledb.connect(
        user=env_required(item.get("user_env", "ORACLE_USER")),
        password=env_required(item.get("password_env", "ORACLE_PASSWORD")),
        dsn=env_required(item.get("dsn_env", "ORACLE_DSN")),
    )


def decimal_text(value: Decimal) -> str:
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return "0" if text in {"", "-0"} else text


def value_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, Decimal):
        return decimal_text(value)
    if isinstance(value, float):
        return decimal_text(Decimal(str(value)))
    if isinstance(value, oracledb.LOB):
        return str(value.read())
    if isinstance(value, bytes):
        return value.hex().upper()
    return str(value)


def escape_field(value: Any, delimiter: str) -> str:
    # 检查组要求标准逗号分隔；字段内容中的英文逗号直接移除，避免串列。
    text = value_text(value).replace(",", "")
    if delimiter in text or '"' in text or "\r" in text or "\n" in text:
        return '"' + text.replace('"', '""') + '"'
    return text


def build_query(table: dict[str, Any]) -> tuple[str, bool]:
    owner = identifier(table["owner"])
    object_name = identifier(table["object_name"])
    date_column_value = table.get("date_column")
    has_date_filter = bool(date_column_value and str(date_column_value).strip())
    sql = f"SELECT * FROM {owner}.{object_name}"
    conditions: list[str] = []
    if has_date_filter:
        date_column = identifier(str(date_column_value).strip())
        conditions.append(
            f"{date_column} >= :start_date AND {date_column} < :end_date"
        )
    extra_where = table.get("extra_where")
    if extra_where:
        if ";" in extra_where or "--" in extra_where or "/*" in extra_where:
            raise ValueError(f"{table['export_name']} 的 extra_where 含不允许的内容")
        conditions.append(f"({extra_where})")
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    if has_date_filter:
        sql += f" ORDER BY {date_column}"
    return sql, has_date_filter


def cursor_columns(cursor: oracledb.Cursor) -> list[str]:
    """按视图定义顺序取得查询结果字段名，作为 CSV 表头。"""
    if not cursor.description:
        raise RuntimeError("Oracle 查询未返回字段元数据")
    columns = [str(item[0]).upper() for item in cursor.description]
    if len(columns) != len(set(columns)):
        raise RuntimeError("视图存在重复字段名，无法生成唯一 CSV 表头")
    return columns


def write_rows(
    cursor: oracledb.Cursor,
    output_path: Path,
    columns: list[str],
    encoding: str,
    export_name: str,
    progress_rows: int,
) -> tuple[int, int, str]:
    """使用英文逗号流式导出，字段内容中的英文逗号由 escape_field 移除。"""
    digest = hashlib.sha256()
    row_count = 0
    skipped_count = 0
    processed_count = 0
    delimiter = ","
    with output_path.open("wb") as raw:
        def render(values: Iterable[Any]) -> bytes:
            line = delimiter.join(escape_field(value, delimiter) for value in values) + "\n"
            return line.encode(encoding)

        header = render(columns)
        raw.write(header)
        digest.update(header)
        for row in cursor:
            processed_count += 1
            try:
                data = render(row)
            except Exception as exc:
                skipped_count += 1
                # 只记录来源行号和异常，不记录患者字段内容。
                LOG.error(
                    "[%s] 第 %s 行转换失败，已跳过；异常类型：%s",
                    export_name,
                    f"{processed_count:,}",
                    type(exc).__name__,
                )
                continue
            # 磁盘写入错误属于系统性故障，交给表级异常处理，不能静默跳过。
            raw.write(data)
            digest.update(data)
            row_count += 1
            if progress_rows > 0 and processed_count % progress_rows == 0:
                LOG.info(
                    "[%s] 已处理 %s 行，成功 %s 行，跳过 %s 行",
                    export_name,
                    f"{processed_count:,}",
                    f"{row_count:,}",
                    f"{skipped_count:,}",
                )
    return row_count, skipped_count, digest.hexdigest()


def oracle_column_type(row: tuple[Any, ...]) -> str:
    """根据 ALL_TAB_COLUMNS 元数据重建用于 CSV 导入的字段类型。"""
    data_type, data_length, data_precision, data_scale, char_length, char_used = row
    data_type = str(data_type).upper()
    if data_type in {"VARCHAR2", "CHAR", "NVARCHAR2", "NCHAR"}:
        length = char_length if char_used == "C" and char_length else data_length
        suffix = " CHAR" if char_used == "C" and data_type in {"VARCHAR2", "CHAR"} else ""
        return f"{data_type}({int(length)}{suffix})"
    if data_type == "NUMBER":
        if data_precision is None:
            return "NUMBER"
        if data_scale is None:
            return f"NUMBER({int(data_precision)})"
        return f"NUMBER({int(data_precision)},{int(data_scale)})"
    if data_type == "FLOAT" and data_precision is not None:
        return f"FLOAT({int(data_precision)})"
    if data_type.startswith("TIMESTAMP"):
        return data_type
    if data_type == "RAW":
        return f"RAW({int(data_length)})"
    return data_type


def get_import_table_ddl(
    connection: oracledb.Connection,
    owner: str,
    object_name: str,
    target_table_name: str,
) -> str:
    """生成不依赖来源业务对象、可直接导入 CSV 的空表 DDL。"""
    owner = identifier(owner)
    object_name = identifier(object_name)
    target_table_name = identifier(target_table_name)
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT column_name, data_type, data_length, data_precision, data_scale, "
            "       char_length, char_used "
            "FROM all_tab_columns "
            "WHERE owner=:owner AND table_name=:name "
            "ORDER BY column_id",
            owner=owner,
            name=object_name,
        )
        rows = cursor.fetchall()
    if not rows:
        return f"-- 未找到或无权读取 {owner}.{object_name} 的字段定义\n"
    definitions = [
        f"    {identifier(row[0])} {oracle_column_type(tuple(row[1:]))}" for row in rows
    ]
    return (
        f"-- CSV 数据来源：{owner}.{object_name}\n"
        "-- 本语句用于创建独立空表后重新导入 CSV 数据。\n"
        f"CREATE TABLE {target_table_name} (\n"
        + ",\n".join(definitions)
        + "\n);\n"
    )


def export_one_table(
    index: int,
    config: dict[str, Any],
    table: dict[str, Any],
    start_date: datetime,
    end_date: datetime,
    output_dir: Path,
    hospital: str,
    date_range: str,
) -> tuple[int, dict[str, Any]]:
    export = config["export"]
    export_name = table["export_name"]
    sql, has_date_filter = build_query(table)
    filename = f"{hospital}_{safe_filename(export_name)}_{date_range}.csv"
    output_path = output_dir / filename
    working_path = output_path.with_suffix(".csv.part")
    ddl_path = output_path.with_suffix(".sql")
    ddl_working_path = output_path.with_suffix(".sql.part")
    started = time.monotonic()
    LOG.info("[%s] 开始导出：%s", export_name, output_path)
    LOG.info(
        "[%s] 提取模式：%s，来源：%s.%s",
        export_name,
        "按日期" if has_date_filter else "全量",
        identifier(table["owner"]),
        identifier(table["object_name"]),
    )

    # python-oracledb 连接不能在并发线程间共用，每张表创建独立连接。
    with connect(config) as connection:
        with connection.cursor() as cursor:
            cursor.arraysize = int(export.get("fetch_size", 5000))
            cursor.prefetchrows = cursor.arraysize
            if has_date_filter:
                cursor.execute(sql, start_date=start_date, end_date=end_date)
            else:
                cursor.execute(sql)
            columns = cursor_columns(cursor)
            LOG.info("[%s] 查询已执行，字段数：%d", export_name, len(columns))
            row_count, skipped_count, sha256 = write_rows(
                cursor,
                working_path,
                columns,
                export.get("encoding", "utf-8"),
                export_name,
                int(export.get("progress_rows", 100000)),
            )

        if export.get("write_ddl", True):
            ddl_working_path.write_text(
                get_import_table_ddl(
                    connection,
                    table["owner"],
                    table["object_name"],
                    table.get("target_table_name", table["object_name"]),
                ),
                encoding="utf-8",
            )

    # CSV 与建表 SQL 均处理完成后才发布为正式文件名。
    working_path.replace(output_path)
    completed_files = [filename]
    if export.get("write_ddl", True):
        ddl_working_path.replace(ddl_path)
        completed_files.append(ddl_path.name)
        LOG.info("[%s] 建表语句已生成：%s", export_name, ddl_path)

    elapsed = time.monotonic() - started
    LOG.info(
        "[%s] 导出完成：成功 %s 行，跳过 %s 行，耗时 %.2f 秒，SHA256=%s",
        export_name,
        f"{row_count:,}",
        f"{skipped_count:,}",
        elapsed,
        sha256,
    )
    return index, {
        "status": "completed_with_skips" if skipped_count else "completed",
        "export_name": export_name,
        "filename": filename,
        "completed_files": completed_files,
        "row_count": row_count,
        "skipped_row_count": skipped_count,
        "source_row_count": row_count + skipped_count,
        "sha256": sha256,
        "elapsed_seconds": round(elapsed, 2),
        "delimiter": ",",
        "comma_in_field": "removed",
        "extraction_mode": "date_range" if has_date_filter else "full",
        "date_column": table.get("date_column") or None,
        "source": f"{identifier(table['owner'])}.{identifier(table['object_name'])}",
    }


def main() -> int:
    configure_logging()
    parser = argparse.ArgumentParser(description="Oracle 检查数据 CSV 导出工具")
    parser.add_argument("--config", default="config.json", type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    export = config["export"]
    start_date = datetime.strptime(export["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(export["end_date"], "%Y-%m-%d")
    if start_date >= end_date:
        raise ValueError("start_date 必须早于 end_date；end_date 为开区间")

    output_dir = Path(export.get("output_dir", "./output")).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    hospital = safe_filename(export["hospital_name"])
    date_range = f"{start_date:%Y%m%d}-{end_date:%Y%m%d}"
    log_path = output_dir / f"{hospital}_导出日志_{date_range}.log"
    add_file_logging(log_path)
    LOG.info("运行日志：%s", log_path)
    encoding = export.get("encoding", "utf-8")
    manifest: dict[str, Any] = {
        "hospital_name": export["hospital_name"],
        "start_date_inclusive": export["start_date"],
        "end_date_exclusive": export["end_date"],
        "delimiter": ",",
        "comma_in_field": "removed",
        "encoding": encoding,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "files": [],
    }

    max_workers = max(1, int(export.get("max_workers", 4)))
    max_workers = min(max_workers, len(config["tables"]))
    LOG.info("开始导出，共 %d 张表，并发线程数：%d", len(config["tables"]), max_workers)
    results: dict[int, dict[str, Any]] = {}
    failures: list[dict[str, str]] = []
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="export") as pool:
        futures = {
            pool.submit(
                export_one_table,
                index,
                config,
                table,
                start_date,
                end_date,
                output_dir,
                hospital,
                date_range,
            ): (index, table)
            for index, table in enumerate(config["tables"])
        }
        for future in as_completed(futures):
            index, table = futures[future]
            try:
                result_index, result = future.result()
                results[result_index] = result
            except Exception as exc:
                LOG.exception("[%s] 导出失败：%s", table["export_name"], exc)
                failures.append({"export_name": table["export_name"], "error": str(exc)})

    manifest["files"] = [results[index] for index in sorted(results)]
    manifest["failures"] = failures
    manifest["completed_files"] = [
        filename
        for index in sorted(results)
        for filename in results[index]["completed_files"]
    ]

    manifest_path = output_dir / f"{hospital}_导出清单_{date_range}.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    completed_list_path = output_dir / f"{hospital}_完成文件清单_{date_range}.txt"
    completed_lines = [
        f"医院：{export['hospital_name']}",
        f"生成时间：{datetime.now():%Y-%m-%d %H:%M:%S}",
        f"成功表数：{len(results)}",
        f"失败表数：{len(failures)}",
        "",
        "【最终完成文件】",
    ]
    for index in sorted(results):
        result = results[index]
        status_text = "完成但有跳过行" if result["skipped_row_count"] else "完成"
        completed_lines.append(
            f"[{status_text}] {result['export_name']}：成功 {result['row_count']} 行，"
            f"跳过 {result['skipped_row_count']} 行"
        )
        completed_lines.extend(f"  - {name}" for name in result["completed_files"])
    if failures:
        completed_lines.extend(["", "【失败表】"])
        completed_lines.extend(
            f"[失败] {item['export_name']}：{item['error']}" for item in failures
        )
    completed_list_path.write_text("\n".join(completed_lines) + "\n", encoding="utf-8")
    LOG.info("导出清单已生成：%s", manifest_path)
    LOG.info("最终完成文件清单已生成：%s", completed_list_path)
    LOG.info("任务结束：成功 %d 张，失败 %d 张", len(results), len(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError, oracledb.DatabaseError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
